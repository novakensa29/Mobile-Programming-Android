package com.example.studlers;

public class taskdata {
    private String subject, task;

    public taskdata(String subject, String task) {
        this.subject = subject;
        this.task = task;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }
}
