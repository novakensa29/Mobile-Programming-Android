package com.example.studlers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class taskadapter extends RecyclerView.Adapter<taskadapter.ViewHolder>{

    taskdata[] taskData;
    Context context;

    public taskadapter(taskdata[] taskData,MainActivity5 activity5) {
        this.taskData = taskData;
        this.context = activity5;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.taskview,parent, false);
        ViewHolder viewHolder = new ViewHolder((view));
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final taskdata taskdataList = taskData[position];
        holder.textViewsubject.setText(taskdataList.getSubject());
        holder.textViewtask.setText(taskdataList.getTask());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,taskdataList.getSubject(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textViewsubject;
        TextView textViewtask;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewtask = itemView.findViewById(R.id.task);
            textViewsubject = itemView.findViewById(R.id.subject);
        }
    }
}
