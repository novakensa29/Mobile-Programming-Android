package com.example.studlers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        RecyclerView recyclerView = findViewById(R.id.reycleview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskdata[] taskData = new taskdata[]{
                new taskdata("Mobile", "Mengerjakan tugas di Figma"),
                new taskdata("Statistika", "Mempelajari mengenaii grafik"),
                new taskdata("PPL 1", "Membuat Web dengan menambahkan foto"),
                new taskdata("PPL 1 P", "Mempelajari mengenai OOP"),
                new taskdata("Pancasila", "Membuat PPT"),
                new taskdata("Proyek 4", "Mencoba strapi"),
                new taskdata("Mobile", "Membuat Home Fan"),
                new taskdata("PPL 1 T", "Membuat update database"),

        };

        taskadapter taskAdapter = new taskadapter(taskData, MainActivity5.this);
        recyclerView.setAdapter(taskAdapter);
    }

    public void Back(View view) {
        Intent intent = new Intent(MainActivity5.this,MainActivity3.class);
        startActivity(intent);
    }

    public void Add(View view) {
        Intent intent = new Intent(MainActivity5.this,MainActivity4.class);
        startActivity(intent);
    }
}